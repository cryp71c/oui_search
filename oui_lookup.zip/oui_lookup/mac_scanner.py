import pip
import os
try:
    import pandas
except:
    pip.main(['install', 'pandas'])
#try:


pandas.set_option('display.max_rows', None)
pandas.set_option('display.max_columns', None)
pandas.set_option('display.width', None)
pandas.set_option('display.max_colwidth', None)
import json
from IPython.display import display
os.system('cls' if os.name == 'nt' else 'clear')
with open("macaddress.io-db.json", 'r', encoding='utf-8') as miodb:
    tmp = json.load(miodb)
    tmp = pandas.json_normalize(tmp)
    tmp = tmp[['oui', 'isPrivate', 'companyName']]

tmp.groupby('companyName')
#display(tmp)
my_var = input("**Please enter the first 6 hex digits in this fasion**\n-- 00:00:00 --\n**Or you can enter a full company name**\n-- TP-Link Tech Co, Ltd, Apple, Inc, Cisco Systems, Inc --\n>")
company = tmp[tmp.apply(lambda row: row.astype(str).str.contains(f'{my_var}').any(), axis=1)]
display(company)

#q = input('Before I display your OUI, would you just like to export this to an Excel Spreadsheet and look at it? (Prefered if searching for a company, default is n)')
#q.upper()

#if q == 'Y' or q == 'YES':
#    print("mt")
#else:
#    print("qt")
#display(company)